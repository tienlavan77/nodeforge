# Forge Schema v1.1

Bộ contract chuẩn hóa cho Forge theo mô hình **Node cũng là một System Agent**.

## Điểm thay đổi so với v1

- Tách `core`, `node`, `project`, `context`, `results`.
- Có `agent.schema.json` dùng chung cho system/AI agent.
- Có `agent-envelope.schema.json` làm protocol chung.
- Có bộ schema riêng cho Node:
  - `node-agent`
  - `node-capability`
  - `node-command`
  - `node-event`
  - `node-state`
- Context có cơ chế **compression có cấu trúc**, không minify source.
- `minify_source` bị khóa `false`.
- Code cần sửa phải giữ source exact; code tham khảo có thể dùng excerpt/summary/signature.
- Có examples thực tế cho Node, Builder, Context Pack, File Change, Test Result và Review Result.

## Context compression

Không minify code để tiết kiệm token.

Thay vào đó:

```text
Code Index
  ↓
symbol selection
  ↓
dependency selection
  ↓
line-range selection
  ↓
deduplication
  ↓
structural/history/test summary
  ↓
Context Pack
  ↓
Builder / Reviewer
```

Nguyên tắc:

> Context nhỏ nhất nhưng vẫn đủ để AI suy luận chính xác.

## Agent model

```text
System Agent
└── Node / Orchestrator

AI Agents
├── Builder
├── Reviewer
├── Planner
└── Tester
```

Node là system agent: deterministic, orchestration/verification, không phải AI reasoning agent.

## Filesystem

Agent được phép trực tiếp đọc/ghi source project.

Node:

- watch filesystem
- index
- verify
- build context
- execute workflow
- quản lý agent
- stream event

`.forge/` là vùng runtime/config do Node quản lý và watcher phải ignore vùng runtime.

## Version

Bộ này dùng schema version `1.1.0`.
